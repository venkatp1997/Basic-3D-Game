make clean
make
./sample2D
